<h1><?php echo e($modo); ?> SERVICIO</h1>

<div class="form-group">
<label for="titulo"> TITULO DEL SERVICIO </label>
<input type="text" class="form-control" name="titulo" required="" value="<?php echo e(isset($servicio->titulo)?$servicio->titulo:''); ?>" id="titulo"> 
</div>
<label for="des"> DESCRIPCION DEL SERVICIO</label>
<div class="form-group">

<textarea name="descripcion" class="form-control" rows="5"  required=""  id="descripcion"><?php echo e(isset($servicio->descripcion)?$servicio->descripcion:''); ?></textarea>
</div>

<div class="form-group">
<label for="imagen"></label>
<?php if(isset($servicio->urlimagen)): ?>
<td><img src="<?php echo e(asset('storage').'/'.$servicio->urlimagen); ?>" width="100" alt=""></td>

<?php endif; ?>
<input type="file" class="form-control" name="urlimagen" required="" id="urlimagen"> 
</div>
<div>
<td><label for="des1">Las imagenes deben tener una tamaño de 400x290</label></td>
</div>
<input type="submit" class="btn btn-success" value="<?php echo e($modo); ?> DATOS ">

<a  href=" <?php echo e(url('servicios/')); ?> " class="btn btn-primary">REGRESAR</a><?php /**PATH C:\xampp\htdocs\Orion\resources\views/servicios/form.blade.php ENDPATH**/ ?>