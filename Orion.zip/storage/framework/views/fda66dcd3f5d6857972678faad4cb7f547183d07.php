

<?php $__env->startSection('content'); ?>
<div class="container">

<?php if(Session::has('mensaje')): ?>
<?php echo e(Session::get('mensaje')); ?>

<?php endif; ?>
<br>

<table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Titulo</th>
            <th>Imagen</th>
            <th>Descripcion</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($servicio->id); ?></td>
            <td><?php echo e($servicio->titulo); ?></td>
            <td><img src="<?php echo e(asset('storage').'/'.$servicio->urlimagen); ?>" width="100" alt=""></td>
            
            <td><?php echo e($servicio->descripcion); ?></td>
            <td>        
            <form action="<?php echo e(url('/servicios/'.$servicio->id.'/edit' )); ?> " method="" class="d-inline" >
            <input type="submit" onclick="return confirm('Quieres editar el registro?')" value="Editar" class="btn btn-warning">
        
            </form>
            |
               
            <form action="<?php echo e(url('/servicios/'.$servicio->id)); ?> " method="post" class="d-inline">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('DELETE')); ?>

                <input type="submit" onclick="return confirm('Quieres borrar el registro?')" value="Borrar" class="btn btn-danger">
        
            </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<br>
<a  href=" <?php echo e(url('servicios/create')); ?> " class="btn btn-success">REGISTRAR NUEVO SERVICIO</a>
<br>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Orion\resources\views/servicios/principal.blade.php ENDPATH**/ ?>